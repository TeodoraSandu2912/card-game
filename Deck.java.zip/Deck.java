package com.bham.pij.assignments.pontoon;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Deck {

    private ArrayList<Card> dealtCards = new ArrayList<>();
    private ArrayList<Card> cards = new ArrayList<>();
    private final String[] values = {"TWO", "THREE", "FOUR", "FIVE", "SIX",
            "SEVEN", "EIGHT", "NINE", "TEN", "JACK", "QUEEN", "KING", "ACE"
    };

    private final String[] suits = {"HEARTS", "SPADES", "CLUBS", "DIAMONDS"};

    public Deck() {
        for (String suit : suits) {
            for (String value : values) {
                cards.add(new Card(suit, value));
            }
        }
        
    }
    public Card dealCard(int i) {
        //daca ai in metoda asta doar return cards.get(i) iti merge test_Deck_reset()

        if (dealtCards.contains(cards.get(i))) {
            return null;
        }

        dealtCards.add(cards.get(i));
        return cards.get(i);
    }

    public void reset() {
        dealtCards = new ArrayList<>();
    }
    public Card getCard(int i) {
        return cards.get(i);
    }

    public int getDeckSize() {
        return cards.size();
    }

}
