package com.bham.pij.assignments.pontoon;

import java.util.ArrayList;

public class Hand {


    ArrayList<Card> handCards;
    private ArrayList<Card> cards = new ArrayList<>();
    private final String[] values = {"TWO", "THREE", "FOUR", "FIVE", "SIX",
            "SEVEN", "EIGHT", "NINE", "TEN", "JACK", "QUEEN", "KING", "ACE"
    };

    private final String[] suits = {"HEARTS", "SPADES", "CLUBS", "DIAMONDS"};

    public Hand() {

        handCards = new ArrayList<>();

    }

    public void addCard (Card c) {
        handCards.add(c);
    }

    public int getHandSize() {
        return handCards.size();
    }

    public Card getCard(int i) {

        if (i >= 0 && i < handCards.size()){
            return handCards.get(i);
        }
        return null;
    }

    public String showHand() {

        String s = "";

        for (int i= 0 ; i < handCards.size(); i++) {
            s += getCard(i).getValue() + " of " + getCard(i).getSuit();
        }
        return s;
    }

    public ArrayList<Integer> getNumericalValue() {

        ArrayList<Integer> numericalValue = new ArrayList<>();

        numericalValue.add(0);

        int zeroResults = 1;
        int value = 0;
        for (int i = 0; i < handCards.size(); i++) {
            if(handCards.get(i).getValue().equals("ACE")) {
                numericalValue.add(numericalValue.get(zeroResults-1)+1);

            }

            for(int j = 0; j < zeroResults; j++) {
                value = numericalValue.get(j) + handCards.get(i).getNumericalValue().get(0);
                numericalValue.set(j,value);
            }

            if(handCards.get(i).getValue().equals("ACE")) {

                zeroResults++;
            }
        }
        return numericalValue;

    }
}




