package com.bham.pij.assignments.pontoon;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Card {

    private String value;
    private String suit;

    public Card(String suit, String value) {
        this.suit = suit;
        this.value = value;
    }

    public String getSuit() {

        return this.suit;
    }

    public String getValue(){
        return this.value;
    }

    public ArrayList<Integer> getNumericalValue(){
        ArrayList<Integer> numericalValues = new ArrayList<>();
        switch (value) {
            case "TWO":
                numericalValues.add(2);
                break;
            case "THREE":
                numericalValues.add(3);
                break;
            case "FOUR":
                numericalValues.add(4);
                break;
            case "FIVE":
                numericalValues.add(5);
                break;
            case "SIX":
                numericalValues.add(6);
                break;
            case "SEVEN":
                numericalValues.add(7);
                break;
            case "EIGHT":
                numericalValues.add(8);
                break;
            case "NINE":
                numericalValues.add(9);
                break;
            case "TEN": case "JACK" : case "QUEEN" : case "KING":
                numericalValues.add(10);
                break;
            case "ACE":
                numericalValues.add(11);
                numericalValues.add(1);
                break;
        }
        return numericalValues;
    }

    public String toString(){
        return this.value + " of " + this.suit;
    }

    public static String getRandomSuit(){
        ArrayList<String> suits = new ArrayList<>(Arrays.asList("HEARTS", "SPADES", "CLUBS", "DIAMONDS"));
        Random random = new Random();

        return suits.get(random.nextInt(suits.size()));
    }

    public static String getRandomValue(){
        ArrayList<String> values = new ArrayList<>(Arrays.asList("TWO", "THREE", "FOUR", "FIVE", "SIX",
                "SEVEN", "EIGHT", "NINE", "TEN", "JACK", "QUEEN", "KING", "ACE"));
        Random random = new Random();

        return values.get(random.nextInt(values.size()));
    }

}
